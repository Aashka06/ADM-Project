Google Docs

https://docs.google.com/document/d/1hwARL_2yVA0002i4AQdbi6yavNxXZrc3lVHauM1mZG8/edit?usp=sharing

CLAAT Document

https://codelabs-preview.appspot.com/?file_id=1hwARL_2yVA0002i4AQdbi6yavNxXZrc3lVHauM1mZG8#0
