Neural Style Transfer

https://docs.google.com/document/d/1uAX5q0vvveRhOXHZc4uCqqW8Y14nHW--TZ9IpphrDjk/edit#

CLAAT DOC: https://codelabs-preview.appspot.com/?file_id=1uAX5q0vvveRhOXHZc4uCqqW8Y14nHW--TZ9IpphrDjk#0

Image Similarity

https://docs.google.com/document/d/1pPPrbFaqre-8qiw6TmDPYv0EsGUjNDvrHZEcoyAw8dk/edit#

CLAAT DOC: https://codelabs-preview.appspot.com/?file_id=1pPPrbFaqre-8qiw6TmDPYv0EsGUjNDvrHZEcoyAw8dk#0

Image Search By an Artistic Style

https://docs.google.com/document/d/1HQe63QV8dOyTDGqkF32nMU4Iz0TYvO9DaK1Leo5qdOE/edit?usp=sharing

CLAAT DOC: https://codelabs-preview.appspot.com/?file_id=1HQe63QV8dOyTDGqkF32nMU4Iz0TYvO9DaK1Leo5qdOE#0
