Snowflake and Einstein Analytics Lab

https://codelabs-preview.appspot.com/?file_id=1Zmfl-OUwsouDWxnIvxH29KVPOQq9B_gdDo_Rbw7wleQ#4

https://docs.google.com/document/d/1Zmfl-OUwsouDWxnIvxH29KVPOQq9B_gdDo_Rbw7wleQ/edit?usp=sharing
