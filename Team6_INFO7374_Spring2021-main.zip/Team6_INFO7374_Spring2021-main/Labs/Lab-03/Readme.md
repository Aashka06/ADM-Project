Churn Prediction using LSTM and comparing it with baseline model

https://docs.google.com/document/d/1v_uoakynqCbMV9l5SurIGBlaN7rCJ1oSfwqv4EkD8xQ/edit?usp=sharing

https://codelabs-preview.appspot.com/?file_id=1v_uoakynqCbMV9l5SurIGBlaN7rCJ1oSfwqv4EkD8xQ#0
