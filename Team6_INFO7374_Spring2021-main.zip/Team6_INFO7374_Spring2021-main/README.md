# Team6_INFO7374_Spring2021
Lab and assignments done during the class are in this repository. Feel free to explore and let us know about any discrepancies/things we can add to better them. 
