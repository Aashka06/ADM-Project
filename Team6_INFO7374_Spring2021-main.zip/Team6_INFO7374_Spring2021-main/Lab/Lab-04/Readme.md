Calculating Customer Lifetime Value

https://docs.google.com/document/d/1M-f149cti62Vnwghjp218aIWhd5QBpLfiqpQLshiVrU/edit#

https://codelabs-preview.appspot.com/?file_id=1M-f149cti62Vnwghjp218aIWhd5QBpLfiqpQLshiVrU#0

CLV: Calculating Customer Lifetimes(Databricks)

https://docs.google.com/document/d/1Jr1zJtzQ8OZTAfM7TVNgFN-MRzOnxbKlGKv1q1NrPSs/edit#

https://codelabs-preview.appspot.com/?file_id=1Jr1zJtzQ8OZTAfM7TVNgFN-MRzOnxbKlGKv1q1NrPSs#0

CLV-estimating future spend (Databricks)

https://docs.google.com/document/d/1cdYvjYA93JUQ8k94dCbZE4V2qpYEB-Lla_qTKze1ntQ/edit#heading=h.689k60xq1whi

https://codelabs-preview.appspot.com/?file_id=1cdYvjYA93JUQ8k94dCbZE4V2qpYEB-Lla_qTKze1ntQ#0

RFM-Segmentation

https://docs.google.com/document/d/1Jr1zJtzQ8OZTAfM7TVNgFN-MRzOnxbKlGKv1q1NrPSs/edit#

https://codelabs-preview.appspot.com/?file_id=1gCwRFVIXitjnRUxYfokeHEKNsBrEPy3ksmOvmrI44aw#0
