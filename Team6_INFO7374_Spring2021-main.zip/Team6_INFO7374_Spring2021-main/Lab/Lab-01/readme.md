Google BigQuery Lab

https://codelabs-preview.appspot.com/?file_id=1-dkpjdlv5m_jE9sYN3xHA0c3vhtJWzM3m7PHccvqodM#0

https://docs.google.com/document/d/1-dkpjdlv5m_jE9sYN3xHA0c3vhtJWzM3m7PHccvqodM/edit?usp=sharing

Churn Prediction using LSTM and comparing it with baseline model

https://docs.google.com/document/d/1v_uoakynqCbMV9l5SurIGBlaN7rCJ1oSfwqv4EkD8xQ/edit?usp=sharing

https://codelabs-preview.appspot.com/?file_id=1v_uoakynqCbMV9l5SurIGBlaN7rCJ1oSfwqv4EkD8xQ#0


Snowflake and Einstein Analytics Lab

https://codelabs-preview.appspot.com/?file_id=1Zmfl-OUwsouDWxnIvxH29KVPOQq9B_gdDo_Rbw7wleQ#4

https://docs.google.com/document/d/1Zmfl-OUwsouDWxnIvxH29KVPOQq9B_gdDo_Rbw7wleQ/edit?usp=sharing


XSV tutorial 

https://codelabs-preview.appspot.com/?file_id=1LqSkYVcBj5lPDfZ7V-FvYkR3x6pXDGYOPXgkhRfhqig#1

https://docs.google.com/document/d/1LqSkYVcBj5lPDfZ7V-FvYkR3x6pXDGYOPXgkhRfhqig/edit?usp=sharing
