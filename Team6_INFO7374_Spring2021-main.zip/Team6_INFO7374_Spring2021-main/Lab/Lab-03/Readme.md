Latent Semantic Analysis

https://codelabs-preview.appspot.com/?file_id=1AVeoXzJkXDHMBfStyHRvjCVJGtGcYpn6tZ2POqWNALw#1

https://docs.google.com/document/d/1AVeoXzJkXDHMBfStyHRvjCVJGtGcYpn6tZ2POqWNALw/edit#heading=h.ydmpaatuxv5l
