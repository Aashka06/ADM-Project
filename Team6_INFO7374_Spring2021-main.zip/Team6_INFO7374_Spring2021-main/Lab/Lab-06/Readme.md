Immersion Day Amazon Lab

Google Document:

https://docs.google.com/document/d/1BNvxCmKKKhUOgpW_jwrWkehypkT8BYeE4Kbkg41O3Rk/edit?usp=sharing

Clat:

