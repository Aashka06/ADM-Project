XSV tutorial 

https://codelabs-preview.appspot.com/?file_id=1LqSkYVcBj5lPDfZ7V-FvYkR3x6pXDGYOPXgkhRfhqig#1

https://docs.google.com/document/d/1LqSkYVcBj5lPDfZ7V-FvYkR3x6pXDGYOPXgkhRfhqig/edit?usp=sharing

Twitter Web Scraping using Twitter API 

https://codelabs-preview.appspot.com/?file_id=1TNr7pWULuttfAVexzB3X5HgBsqMpRFGjAW9EYjRD25c#1

Amazon Web Scraping using Beautiful Soup

https://docs.google.com/document/d/1TNr7pWULuttfAVexzB3X5HgBsqMpRFGjAW9EYjRD25c/edit?usp=sharing

Streamlit

https://docs.google.com/document/d/1hwARL_2yVA0002i4AQdbi6yavNxXZrc3lVHauM1mZG8/edit?usp=sharing

https://codelabs-preview.appspot.com/?file_id=1hwARL_2yVA0002i4AQdbi6yavNxXZrc3lVHauM1mZG8#0

Google Docs

https://docs.google.com/document/d/1hwARL_2yVA0002i4AQdbi6yavNxXZrc3lVHauM1mZG8/edit?usp=sharing

CLAAT Document

https://codelabs-preview.appspot.com/?file_id=1hwARL_2yVA0002i4AQdbi6yavNxXZrc3lVHauM1mZG8#0

