Google Doc:

https://docs.google.com/document/d/1UYcb3HOS7xeVAG8d4lUn4yzx_JiojlsS34E9HbOJz-Q/edit?usp=sharing
