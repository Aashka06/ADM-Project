USHolidays.csv dataset for augmentation with TPC-DS dataset.
