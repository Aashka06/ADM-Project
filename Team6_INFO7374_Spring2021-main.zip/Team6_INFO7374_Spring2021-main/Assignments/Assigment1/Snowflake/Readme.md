Snowflake sql script for querying TPC-DS
