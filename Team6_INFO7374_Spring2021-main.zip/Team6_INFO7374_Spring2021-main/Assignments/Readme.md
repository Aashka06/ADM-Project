Here are all the assignments done during the INFO7374 Algorithmic Digital Marketing class.
